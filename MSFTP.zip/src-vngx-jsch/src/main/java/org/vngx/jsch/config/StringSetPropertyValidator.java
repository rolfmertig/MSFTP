/*
 * Copyright (c) 2010-2011 Michael Laudati, N1 Concepts LLC.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The names of the authors may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL N1
 * CONCEPTS LLC OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.vngx.jsch.config;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Implementation of {@code PropertyValidator} which validates by checking if a
 * string property is contained in the set of allowed values passed to the
 * constructor.
 *
 * @author Michael Laudati
 */
public class StringSetPropertyValidator extends PropertyValidator {

	/** Set of valid strings to check against for valid properties. */
	protected final Set<String> _validSet = new HashSet<String>();


	/**
	 * Creates a new instance of {@code StringSetPropertyValidator} which only
	 * returns a property as valid if it matches a String contained in the
	 * specified {@code validSet} and sets the default value as the first value
	 * returned by the iterator of the valid set.
	 * 
	 * @param validSet
	 */
	public StringSetPropertyValidator(Set<String> validSet) {
		this(validSet.iterator().next(), validSet);
	}

	/**
	 * Creates a new instance of {@code StringSetPropertyValidator} which only
	 * returns a property as valid if it matches a String contained in the
	 * specified {@code validSet}.
	 *
	 * @param defaultValue
	 * @param validSet
	 */
	public StringSetPropertyValidator(String defaultValue, Set<String> validSet) {
		super(defaultValue);
		_validSet.addAll(validSet);
	}

	/**
	 * Creates a new instance of {@code StringSetPropertyValidator} which only
	 * returns a property as valid if it matches a String contained in the
	 * specified {@code validSet}.
	 *
	 * @param defaultValue
	 * @param validSet
	 */
	public StringSetPropertyValidator(String defaultValue, String... validSet) {
		super(defaultValue);
		_validSet.addAll(Arrays.asList(validSet));
	}

	@Override
    protected boolean isPropertyValid(String property) {
        return property != null && _validSet.contains(property);
    }

}
